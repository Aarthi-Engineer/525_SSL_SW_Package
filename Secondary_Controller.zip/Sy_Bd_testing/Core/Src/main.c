/* USER CODE BEGIN Header */
/** Machine Serial.No: 23KCON-1_Sy
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_hal.h"
#include <stdio.h>
#include<string.h>

uint8_t RxBuffer[9]={0};//Rxbuffer
uint8_t Receive = 0;

uint8_t pattern;
float spot_size = 0.2,Temp_spot_size = 0.2;
uint16_t AD_RES=0;

#define SHT4x_ADDR         (0x44 << 1)  // Shifted for HAL
#define SHT4x_MEASURE_CMD  0xFD         // High precision measurement
#define SHT4x_SERIAL_CMD   0x89         // Read serial number

void SHT4x_readSerialNumber();
void SHT40_readMeasurement();

char msg[500];
int Presence,Initial_Temp=0;
volatile uint8_t isTxed = 0,isRxed=0;
uint8_t RxData[8],Temp_LSB,Temp_MSB;
float Temperature;
float Console_Temperature = 26.0;
float Board_Temperature;
void uart_init(uint32_t);
int DS18B20_Start(void);
void DS18B20_Write (uint8_t);
uint8_t DS18B20_Read (void);

ADC_HandleTypeDef hadc1;

I2C_HandleTypeDef hi2c2;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;
DMA_HandleTypeDef hdma_usart2_tx;



/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_I2C2_Init(void);

void Spot_size_read();

int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_USART1_UART_Init();
  MX_I2C2_Init();
  /* USER CODE BEGIN 2 */
  HAL_ADC_Start(&hadc1);
  /* USER CODE END 2 */
/*  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, 1);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 1);*/
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
	 // HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, 0);
	  for(int i=0;i<10;i++)
	  {
	  Presence = DS18B20_Start ();
	  	  DS18B20_Write (0xCC);  // skip ROM
	  	  DS18B20_Write (0x44);  // convert t


	  	  Presence = DS18B20_Start ();
	  	  DS18B20_Write (0xCC);  // skip ROM
	  	  DS18B20_Write (0xBE);  // Read Scratch-pad


	  	   Temp_LSB = DS18B20_Read();
	  	 /*  sprintf(msg, "Raw Temp LSB: 0x%02X", Temp_LSB);
	  	   HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);*/
	  	   HAL_UART_Abort(&huart2);

	  	   Temp_MSB = DS18B20_Read();
	  	   //Temp_MSB = 0xFF;
	  	  /* sprintf(msg, "Raw Temp MSB: 0x%02X", Temp_MSB);
	  	   HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);*/


			int16_t Temp = ((Temp_MSB<<8))|Temp_LSB;
			Temperature = (float)Temp/16.0;  // resolution is 0.0625
			if(Temperature>50.00)
			{
			  Temperature = 24.00;
			}
	      }
	 // Temperature = 31.0;
	//  	  Temperature = 0.0625;
	  	 /* sprintf(msg, "Temp: %d\r\n", Temp);  // print with 2 decimal places

	  	  HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);*/
	  	  sprintf(msg, "Temp: %.4f\r\n", Temperature);  // print with 2 decimal places

	  	//  HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);
	  	//Temperature = 24;


	  	if((Temperature>37.0)||(Temperature<0.0))//if(Console_Temperature>25.0) //30
	  	  {
	  		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_10, 0);
	  		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, 1);

	  	  }
	  	  else
	  	  {
	  	    //HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, 1);
	  	   // HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 1);
	  		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_10, 1);
	  		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, 0);
	  	  }

	  	  //HAL_Delay(100);
	  	  SHT40_readMeasurement();
	  	  SHT4x_readSerialNumber();
	  	  //HAL_Delay(100);

	  	  while( HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7) == 0){};//Commented for Testing
		  //Spot_size_read();

		  Receive=0;

		  HAL_UART_Receive_IT(&huart1,&Receive,sizeof(Receive));


		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, 0);

	      /* USER CODE BEGIN 3 */
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

void SHT40_readMeasurement() {
    HAL_StatusTypeDef ret;
    uint8_t cmd = SHT4x_MEASURE_CMD;
    uint8_t data_rx[6];

    // Send measurement command
    ret = HAL_I2C_Master_Transmit(&hi2c2, SHT4x_ADDR, &cmd, 1, 100);
    if (ret != HAL_OK) {
    	//sprintf(msg, "Error\r\n");  // print with 2 decimal places

    	//HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);
        return;
    }

    HAL_Delay(10);  // Wait for measurement

    // Read 6 bytes: T(2) + CRC + RH(2) + CRC
    ret = HAL_I2C_Master_Receive(&hi2c2, SHT4x_ADDR, data_rx, 6, 100);
    if (ret != HAL_OK) {
    	//sprintf(msg, "Error\r\n");  // print with 2 decimal places

    	//HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);
        return;
    }

    uint16_t t_ticks = (data_rx[0] << 8) | data_rx[1];
    uint16_t rh_ticks = (data_rx[3] << 8) | data_rx[4];

    float t_degC = -45 + 175 * ((float)t_ticks / 65535);
    Board_Temperature = t_degC;
   // Board_Temperature = 24;
   // float rh_pRH = -6 + 125 * ((float)rh_ticks / 65535);

    if(Board_Temperature>40)//40
    	  	  {
    	  		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_11, 0);
    	  		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, 1);

    	  	  }
    	  	  else
    	  	  {
    	  		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_11, 1);
    	  		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9,0);

    	  	  }

   // sprintf(msg, "Temperature: %.2f °C\r\n",t_degC);  // print with 2 decimal places

    //HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);



}


void SHT4x_readSerialNumber() {
    HAL_StatusTypeDef ret;
    uint8_t cmd = SHT4x_SERIAL_CMD;
    uint8_t serial_rx[6];

    ret = HAL_I2C_Master_Transmit(&hi2c2, SHT4x_ADDR, &cmd, 1, 100);
    if (ret != HAL_OK) {
       // printf("Serial Tx Error\r\n");

     //   sprintf(msg, "Serial Tx Error\r\n");  // print with 2 decimal places

      //  HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_11, 0);

        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, 1);
        return;
    }

    HAL_Delay(1);  // Short delay

    ret = HAL_I2C_Master_Receive(&hi2c2, SHT4x_ADDR, serial_rx, 6, 100);
    if (ret != HAL_OK) {
    	//sprintf(msg, "Serial Rx Error\r\n");  // print with 2 decimal places
    	//HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);
        return;
    }

    uint32_t serial = (serial_rx[0] << 8 | serial_rx[1]) << 16 |
                      (serial_rx[3] << 8 | serial_rx[4]);


 /*   sprintf(msg, "SHT4x Serial Number: 0x%08lX\r\n",serial);  // print with 2 decimal places

    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);*/
}
void uart_init(uint32_t baud)
{
	  huart2.Instance = USART2;
	  huart2.Init.BaudRate = baud;
	  huart2.Init.WordLength = UART_WORDLENGTH_8B;
	  huart2.Init.StopBits = UART_STOPBITS_1;
	  huart2.Init.Parity = UART_PARITY_NONE;
	  huart2.Init.Mode = UART_MODE_TX_RX;
	  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	  if (HAL_HalfDuplex_Init(&huart2) != HAL_OK)
	  {
	    Error_Handler();
	  }
}
int DS18B20_Start(void)
{
	uint8_t data = 0xF0;
	uart_init(9600);
	HAL_UART_Transmit(&huart2, &data, 1, 1000);  // low for 500+ms
	if (HAL_UART_Receive(&huart2, &data, 1, 1000) != HAL_OK) return -1;   // failed.. check connection
	uart_init(115200);
	if (data == 0xF0) return -2;  // no response.. check connection
	return 1;  // response detected
}

void DS18B20_Write (uint8_t data)
{
	uint8_t buffer[8];
	for (int i=0; i<8; i++)
	{
	if ((data & (1<<i))!=0)  // if the bit is high
	{
	 buffer[i] = 0xFF;  // write 1
	}
	else  // if the bit is low
	{
	 buffer[i] = 0;  // write 0
	}
	}
	HAL_UART_Transmit(&huart2, buffer, 8, 1000);
}

uint8_t DS18B20_Read (void)
{
	uint8_t buffer[8];
	uint8_t value = 0;
	for (int i=0; i<8; i++)
	{
	 buffer[i] = 0xFF;
	}

	HAL_UART_Transmit_DMA(&huart2, buffer, 8);
	HAL_UART_Receive_DMA(&huart2, RxData, 8);
	while (isRxed == 0);
	for (int i=0;i<8;i++)
	{
	 if (RxData[i]==0xFF)  // if the pin is HIGH
	 {
	   value |= 1<<i;  // read = 1
	 }
	}
	isRxed = 0;
	return value;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{

	//HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, 1);
	if (huart->Instance == USART2)
	{
	isRxed = 1;
	}
	else if(huart->Instance == USART1)
	{

	HAL_UART_Receive_IT(&huart1, &Receive,sizeof(Receive));
	//HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_9);
	//HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, 1);
		pattern = Receive;
		if( Receive == 0x5A)
		{
			 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, 1);
			 //HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_9);

		}
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, 0);
	}

}

void Spot_size_read()
{
  /**********************************************************************
               ADC for Spot size 100um, 200um, 300um, 400um, 500um
   **********************************************************************/

  if(HAL_ADC_PollForConversion(&hadc1, 1000) == HAL_OK) // Poll ADC1 Perihperal & TimeOut = 1mSec
 {
       AD_RES = HAL_ADC_GetValue(&hadc1); // Read The ADC Conversion Result & Map It To PWM DutyCycle

 }


  if ((AD_RES >= 2200) && (AD_RES < 4000))
  {
	  spot_size=0.1;
  }
  else if ((AD_RES > 1800) && (AD_RES <= 2200))
  {
	  spot_size = 0.2;
  }
  else if ((AD_RES > 1410) && (AD_RES <= 1850))
  {
	  spot_size = 0.3;
  }
  else if ((AD_RES > 1110) && (AD_RES <= 1400))
  {
	  spot_size = 0.4;
  }
  else if ((AD_RES <= 1100))//((AD_RES > 100) && (AD_RES <= 800))
  {
	  spot_size = 0.5;
  }

  if(Temp_spot_size == spot_size)
  {
	//HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, 0);
  }
  else
  {
	  Temp_spot_size = spot_size;
	  //HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, 1);
  }

 }

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if((GPIO_Pin == GPIO_PIN_7)||(GPIO_Pin == GPIO_PIN_6)||(GPIO_Pin == GPIO_PIN_0)||(GPIO_Pin == GPIO_PIN_1)||(GPIO_Pin == GPIO_PIN_4)||(GPIO_Pin == GPIO_PIN_5)||(GPIO_Pin == GPIO_PIN_3))//) // If The INT Source Is EXTI Line6 (C6 Pin)
    {
    	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, 1); // Toggle The Output (LED) Pin
    }
//Here also we can think of making PC8 zero immediately to interrupt faster, in future this might raise an issue beware of the incident happened in UART Call back
}



/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */
  __HAL_RCC_ADC1_CLK_ENABLE();

     __HAL_RCC_GPIOB_CLK_ENABLE();

  /* USER CODE END ADC1_Init 1 */
  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.ClockSpeed = 100000;
  hi2c2.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_HalfDuplex_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel6_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel6_IRQn);
  /* DMA1_Channel7_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel7_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel7_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LD4_Pin|LD3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC0 PC6 PC7 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LD4_Pin LD3_Pin */
  GPIO_InitStruct.Pin = LD4_Pin|LD3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

/*  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);*/

  /*Configure GPIO pins : PB1 PB4 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_1;//ENDO
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_4;//LIO
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_5;//SLA
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_3;//For Fibre Detection
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;//GPIO_MODE_IT_RISING
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  HAL_NVIC_SetPriority(EXTI1_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI3_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

  HAL_NVIC_SetPriority(EXTI4_IRQn, 1, 1);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

